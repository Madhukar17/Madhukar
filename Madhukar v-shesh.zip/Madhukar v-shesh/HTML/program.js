// Number -> Any numberical value from Positive, Negative, Fractional, Decimals

// To create a Variable (Temp storage)
// Synax 
// var Variable_Name = Value; 
// Variable_Name -> Any valid text, it should be a-z, A-Z, 0-9, _, $

var age = 28;
console.log(age);